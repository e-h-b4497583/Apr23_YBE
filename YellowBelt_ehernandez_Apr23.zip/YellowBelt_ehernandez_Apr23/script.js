
function hide(element){
    element.remove();
}

function choice(select){
    alert("You are looking for a: " + select.options[select.selectedIndex].text);
}

let count= 3;
var countElement = document.querySelector("#count");
    console.log(countElement);
function add1(){
    count++;
    countElement.innerText = count + " petting(s)";
    console.log(count);
}

function addLike(e){
    let count = Number(e.nextElementSibling.innerText) + 1;
    e.nextElementSibling.innerText = count;
}